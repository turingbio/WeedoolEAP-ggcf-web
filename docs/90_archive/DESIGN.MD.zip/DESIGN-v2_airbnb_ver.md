---
version: alpha
name: WeeDool-EAP-web-v2
tokens: ./tokens.yaml
extends: ./tokens.yaml
description: 흰 캔버스 위에 하늘빛 그라데이션 밴드 하나와 브랜드 블루 한 가지 전압으로 움직이는 모바일 우선 안내 페이지. 앱의 Pretendard 스케일을 웹 가독성 기준(본문 18px)에 맞춰 올려 쓰고, 3D 캐릭터가 아이콘을 대신한다. 이 버전의 특징은 **상태를 프로즈에 묻지 않고 전부 개별 컴포넌트 토큰으로 분리**한 것 — 로딩·비활성·오류·눌림이 각각 이름을 갖는다. 구현자에게 그대로 넘길 수 있는 형태를 목표로 한다.

overrides:
  typography:
    subtitle-desktop: { size: 22px, weight: 600, line: 1.5 }   # 카드 제목을 브레이크포인트별로 분리
    subtitle-mobile:  { size: 20px, weight: 600, line: 1.5 }

components:
  # — Buttons (상태마다 개별 항목)
  button-primary:
    backgroundColor: "{colors.brand}"
    textColor: "{colors.on-brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 24px"
    width: 100%
  button-primary-active:
    backgroundColor: "{colors.brand-strong}"
  button-primary-disabled:
    backgroundColor: "{colors.disabled-bg}"
    textColor: "{colors.disabled-ink}"
    cursor: not-allowed
  button-primary-loading:
    backgroundColor: "{colors.disabled-bg}"
    textColor: "{colors.disabled-ink}"
    label: "발급 중…"
    aria: "aria-busy=true"
  button-secondary:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
  button-secondary-active:
    backgroundColor: "{colors.brand-surface}"
    textColor: "{colors.brand-strong}"
  button-store-pair:
    display: "grid 1fr 1fr"
    gap: "{spacing.md}"
    item: "{components.button-secondary}"
  icon-button-copy:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    size: "{layout.icon-button}"
  icon-button-copy-success:
    message: "복사했어요"
    messageTypography: "{typography.caption-strong}"
    messageColor: "{colors.brand-strong}"
  focus-ring:
    outline: "{elevation.focus}"
  # — Surfaces
  header-minimal:
    backgroundColor: transparent
    logoHeight: 28px
    padding: "{spacing.base} {spacing.lg}"
  hero-band:
    background: "{gradients.hero}"
    textColor: "{colors.ink}"
    padding: "{spacing.section} {spacing.lg}"
  hero-heading:
    typography: "{typography.hero-mobile}"
    accentBackground: "{gradients.heading}"
    accentFallbackColor: "#0695E4"
  section-plain:
    backgroundColor: "{colors.canvas}"
    padding: "{spacing.section} {spacing.lg}"
    maxWidth: "{layout.content-max}"
  section-tinted:
    backgroundColor: "{colors.surface}"
    padding: "{spacing.section} {spacing.lg}"
    maxWidth: "{layout.content-max}"
  section-heading:
    typography: "{typography.title-mobile}"
    accentColor: "{colors.heading-accent}"
    marginBottom: "{spacing.md}"
  # — Cards
  card-anonymity:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
    gap: "{spacing.base}"
    iconSize: 48px
  card-outlined:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{elevation.card}"
  credential-box:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    labelTypography: "{typography.caption}"
    labelColor: "{colors.muted}"
    valueTypography: "{typography.credential}"
    divider: "1px solid {colors.line}"
  credential-expiry-band:
    backgroundColor: "{colors.warning-surface}"
    textColor: "{colors.warning}"
    typography: "{typography.caption-strong}"
    padding: "14px {spacing.xl}"
  # — Forms (상태 분리)
  text-input:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line-control}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 16px"
    typography: "{typography.body}"
    placeholderColor: "{colors.placeholder}"
  text-input-focused:
    border: "2px solid {colors.brand}"
    padding: "0 15px"
  text-input-error:
    border: "2px solid {colors.danger}"
  input-error-message:
    textColor: "{colors.danger}"
    typography: "{typography.caption}"
    marginTop: "{spacing.sm}"
    position: "입력창 아래"
  input-label:
    typography: "{typography.body-strong}"
    marginBottom: "{spacing.sm}"
  # — Media
  app-mockup:
    rounded: "{rounded.lg}"
    shadow: "{elevation.mockup}"
  qr-plate:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    padding: "{spacing.md}"
    size: 160px
  character-avatar:
    size: 48px
  footer-tinted:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.muted}"
    typography: "{typography.caption}"
    borderTop: "1px solid {colors.line}"
    padding: "{spacing.xxl} {spacing.lg}"
  footer-link:
    textColor: "{colors.brand}"
    typography: "{typography.caption}"
  link-inline:
    textColor: "{colors.brand}"
    typography: "{typography.body}"
    hoverColor: "{colors.brand-strong}"
    hoverDecoration: underline
---

## Overview

방문자가 **한 번 스크롤하며 계정을 받아 앱으로 넘어가는** 단선형 페이지다. 기본 바닥은 순백, 글자는 잉크, 브랜드 블루 한 가지 전압이 채워진 버튼·링크·포커스 링을 전부 담당한다. 보조 브랜드 색은 없다.

하늘빛 그라데이션은 유일한 대기감 장치로 히어로와 마지막 CTA 밴드 두 곳에만 쓴다. 그 위 글자는 예외 없이 잉크다.

이 버전이 기준 문서(`DESIGN.md`)와 갈라지는 지점은 **상태를 전부 이름 있는 컴포넌트로 분리**한 것이다. `button-primary-loading`, `text-input-error`, `input-error-message`, `icon-button-copy-success` 가 각각 항목으로 존재한다. 구현자가 프로즈를 읽지 않고 `components:` 만 훑어도 만들 수 있는 형태를 목표로 한다.

**Key Characteristics:**
- 단일 강조색 `{colors.brand}`. 섹션당 채워진 버튼은 하나.
- 히어로 그라데이션 위 글자는 잉크만.
- h1 안의 한 구절만 `{gradients.heading}` — 이 시스템에서 유일하게 색이 글자가 되는 순간.
- 본문 18px · 버튼 20px · 조작 요소 56px. 예외 없음.
- 아이콘을 그리지 않는다. `character/` 3D 캐릭터가 대신한다.
- 그림자 두 단계(카드·목업)뿐. 버튼에는 그림자도 호버 트랜스폼도 없다.
- 상태는 색과 문구를 **함께** 쓴다.

## Colors

팔레트·대비표는 `tokens.yaml`. 이 버전의 배치 규칙:

- `{colors.brand}` 는 유일한 브랜드 전압 — CTA·링크·포커스.
- `{colors.heading-accent}` 는 섹션 제목 안 강조 구절 전용(24px+ Bold).
- `{colors.disabled-bg}` / `{colors.disabled-ink}` 조합은 2.50:1이므로 **비활성 버튼만으로 상태를 알리지 않는다** — `button-primary-disabled` 를 쓸 때는 사유 캡션이 항상 따라붙는다.
- 히어로 그라데이션 위 금지: muted(3.04) · brand(2.67) · 흰 글자.
- 입력창 테두리는 `{colors.line-control}`. `{colors.line}` 은 1.30:1로 장식 전용.

## Typography

스케일은 `tokens.yaml`. 이 버전의 오버라이드는 카드 제목을 브레이크포인트별 두 토큰으로 쪼갠 것뿐이다(`subtitle-mobile` 20px / `subtitle-desktop` 22px) — 상태·크기를 전부 이름으로 갖는다는 이 문서의 방침에 맞춘다.

원칙:
- 본문 18px 하한. 15px은 푸터·오류 문구·법적 고지 세 곳만.
- 한국어 줄바꿈 관리(`keep-all` / `balance` / `pretty`).
- 숫자에 `tnum`.
- 굵기 400 / 600 / 700.

타입 하나로 위계를 만드는 유일한 순간은 **발급 계정 값**(`{typography.credential}`)이다. 방문 이유가 그 두 줄이므로 카드 안에서 가장 큰 글자여야 한다.

## Layout

`tokens.yaml`의 `layout` 을 그대로: 본문 576px, 히어로 960px, 좌우 20px, 조작 요소 56px.

수직 리듬: 섹션 64px(데스크톱 80px) · 제목→본문 12px · 문단 16px · 본문→버튼 24px · 카드 12px · 인접 터치 요소 최소 12px.

섹션 사이 64px, 카드 사이 12px — 다섯 배 차이가 "지금 몇 번째 단계인지" 를 알려주는 유일한 장치다(진행 표시기를 따로 두지 않는다).

## Elevation

| Level | Treatment | Use |
|---|---|---|
| 0 | 평면 | 히어로, 버튼, 섹션 바탕, 푸터 — 표면의 90% |
| 1 | `{elevation.card}` | 카드, 계정 발급 상자 |
| 2 | `{elevation.mockup}` | 앱 스크린 목업 |
| Scrim | `{elevation.scrim}` | 모달 |

깊이는 그라데이션 밴드와 20px 라운드 클리핑에서 나온다. 버튼에 그림자를 넣는 순간 이 시스템의 평평한 신뢰감이 깨진다.

## Components

> 모든 상태는 `components:` 의 개별 항목이다. 아래 프로즈는 왜 그렇게 정했는지만 적는다.

### Buttons
- **`button-primary`** — 섹션당 하나. 눌림에서 `transform` 을 쓰지 않는 이유: 손떨림이 있는 사용자에게 움직이는 버튼은 오조작을 부른다.
- **`button-primary-loading`** — 스피너를 쓰지 않는다. 회전하는 요소는 이 페이지의 정서에 맞지 않고, 라벨 교체가 스크린리더에도 그대로 전달된다.
- **`button-primary-disabled`** — 대비가 낮은 상태이므로 단독으로 쓰지 않는다. 항상 사유 캡션과 한 쌍.
- **`button-store-pair`** — 모바일에서도 가로 2열. 세로로 쌓으면 두 스토어가 위계를 갖는 것처럼 보인다.
- **`focus-ring`** — 모든 조작 요소에 `:focus-visible`. 어떤 상황에서도 제거하지 않는다.

### Forms
- **`text-input`** — `{colors.line-control}` 테두리. 라벨은 `input-label` 로 분리했다 — placeholder를 라벨 대신 쓰는 구현을 막기 위해서다.
- **`text-input-error`** + **`input-error-message`** 는 항상 함께 쓴다. 테두리만 빨개지는 구현은 색맹 사용자에게 아무것도 알리지 못한다.
- 코드 입력 속성: `inputmode="text" autocapitalize="characters" autocomplete="off"`, `letter-spacing: 0.04em`.

### Cards & Credential
- **`card-anonymity`** — 익명성은 이 서비스의 핵심 약속이므로 본문에 섞지 않고 카드로 분리한다. 좌측 48px 캐릭터 + 우측 제목·설명, 3~4장 세로 스택.
- **`credential-box`** — 라벨 위 / 값 아래, 값에 `tnum`. 아이디·비밀번호 사이 구분선.
- **`credential-expiry-band`** — 절대시각 표기(`2026년 9월 14일 18:00까지 유효`). 상대시간은 새로고침·캡처·공유 시 의미가 깨진다.
- **Account PNG Export** — `tokens.yaml`의 `account-png-export`. 화면과 같은 토큰을 쓰고 폰트 로드 후 캔버스로 그린다.

### Navigation & Footer
- **`header-minimal`** — 로고만. 메뉴 없음 — 이 사이트는 한 흐름이고 나갈 곳을 만들지 않는다.
- **`footer-tinted`** — `{colors.surface}` 바탕, 좌측 정렬, 상하 32px.
- **`link-inline`** / **`footer-link`** — 기본 밑줄 없음, hover에 밑줄. 링크 히트영역 44px.

### Signature
- **Hero Gradient Band** — 섹션 전체 폭. 위 글자는 잉크만. 히어로 위 버튼은 `button-primary` 그대로.
- **H1 Gradient Phrase** — 32px+ Bold / 강조 구절 하나 / 그 구절이 정보를 단독 전달하지 않게. 구현은 `DESIGN.md` 의 CSS 스니펫 참조.
- **Character Iconography** — mini 48px, posture 120–200px, emotion. 아이콘을 새로 그리거나 이모지를 쓰지 않는다.

## Responsive Behavior

| Name | Width | Key Changes |
|---|---|---|
| Mobile | < 768px | 1단, 좌우 20px, 섹션 64px, hero 32px / title 24px / 카드 제목 20px |
| Desktop | ≥ 768px | 히어로 960px 2단, 섹션 80px, hero 44px / title 28px / 카드 제목 22px |

본문 폭은 두 구간 모두 576px.

### Touch Targets
버튼·입력창 56px(WCAG AAA 44px 상회), 복사 버튼 48px, 인접 간격 12px, 링크 히트영역 44px.

### Collapsing
- 히어로 2단 → 1단. 다른 섹션은 원래 1단이라 무너질 것이 없다.
- 스토어 버튼 쌍은 모든 폭에서 가로 2열.
- 그라데이션 밴드는 세로 방향 유지.
- 본문 폭은 브레이크포인트를 타지 않는다.

## Iteration Guide

1. 값은 `tokens.yaml` 에서만. 이 문서에 헥스를 다시 쓰지 않는다.
2. 새 상태가 생기면 **프로즈가 아니라 `components:` 항목**으로 추가한다(`-active`, `-disabled`, `-loading`, `-error`).
3. 상태 토큰을 추가할 때 "이 상태를 색 없이도 알 수 있는가" 를 확인한다. 없으면 문구 토큰을 함께 만든다.
4. 색 변경 시 `contrast-ledger` 재계산.

## Known Gaps

- **호버 상태** — 주 사용 환경이 모바일이라 링크 밑줄과 버튼 배경 전환 두 가지만 정의했다. 카드 호버는 의도적으로 없음.
- **모션** — `{motion.button}` 외 정의 없음. 스크롤 진입 애니메이션을 쓴다면 `prefers-reduced-motion` 분기 필수.
- **복사 성공 알림의 지속 시간** — `icon-button-copy-success` 의 문구는 정의했으나 노출 시간·사라지는 방식은 미정.
- 그 외 오류 케이스별 문구·다국어·다크 모드는 `tokens.yaml` 의 `open-questions`.
