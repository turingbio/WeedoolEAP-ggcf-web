---
version: alpha
name: WeeDool-EAP-web
tokens: ./tokens.yaml   # 색·타입·간격·대비표·에셋은 전부 여기. 이 문서는 구조와 배치만.
extends: ./tokens.yaml
description: 위둘(WeeDool) EAP 안내 웹사이트의 기준 문서. 앱 브랜드를 계승한 "일상에서 함께 하는 마음관리" 톤 — 하늘빛 그라데이션 히어로, 흰 캔버스, 3D 캐릭터, 모바일 우선의 큰 글자·큰 터치영역. 브랜드 블루 한 가지가 실행을 담당하고, 그라데이션은 장식 레이어로만 존재한다. 버튼은 56px 높이의 12px 라운드, 카드는 20px, 그림자는 두 단계뿐.

overrides: {}   # 기본값 그대로 사용. 이 문서가 tokens.yaml의 기준 버전이다.

components:
  header-minimal:
    backgroundColor: transparent
    logoHeight: 28px
    padding: "{spacing.base} {spacing.lg}"
  hero-band:
    background: "{gradients.hero}"
    textColor: "{colors.ink}"
    padding: "{spacing.section} {spacing.lg}"
  hero-heading:
    typography: "{typography.hero-mobile}"
    textColor: "{colors.ink}"
    accentBackground: "{gradients.heading}"
    accentFallbackColor: "#0695E4"
  section-plain:
    backgroundColor: "{colors.canvas}"
    padding: "{spacing.section} {spacing.lg}"
    maxWidth: "{layout.content-max}"
  section-tinted:
    backgroundColor: "{colors.surface}"
    padding: "{spacing.section} {spacing.lg}"
    maxWidth: "{layout.content-max}"
  button-primary:
    backgroundColor: "{colors.brand}"
    textColor: "{colors.on-brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 24px"
    width: 100%
  button-primary-pressed:
    backgroundColor: "{colors.brand-strong}"
  button-primary-disabled:
    backgroundColor: "{colors.disabled-bg}"
    textColor: "{colors.disabled-ink}"
  button-secondary:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
  button-secondary-pressed:
    backgroundColor: "{colors.brand-surface}"
    textColor: "{colors.brand-strong}"
  icon-button-copy:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    size: "{layout.icon-button}"
  card-soft:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
    iconSize: 48px
  card-outlined:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    shadow: "{elevation.card}"
  credential-box:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    valueTypography: "{typography.credential}"
    labelTypography: "{typography.caption}"
    labelColor: "{colors.muted}"
  expiry-band:
    backgroundColor: "{colors.warning-surface}"
    textColor: "{colors.warning}"
    typography: "{typography.caption-strong}"
    padding: "14px {spacing.xl}"
  text-input:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line-control}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 16px"
    typography: "{typography.body}"
    placeholderColor: "{colors.placeholder}"
  text-input-focused:
    border: "2px solid {colors.brand}"
    padding: "0 15px"
  text-input-error:
    border: "2px solid {colors.danger}"
    messageColor: "{colors.danger}"
    messageTypography: "{typography.caption}"
  app-mockup:
    rounded: "{rounded.lg}"
    shadow: "{elevation.mockup}"
  qr-plate:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    padding: "{spacing.md}"
    size: 160px
  footer:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.muted}"
    typography: "{typography.caption}"
    borderTop: "1px solid {colors.line}"
    padding: "{spacing.xxl} {spacing.lg}"
  link-inline:
    textColor: "{colors.brand}"
    typography: "{typography.body}"
    hoverColor: "{colors.brand-strong}"
    hoverDecoration: underline
---

## Overview

위둘 EAP 안내 웹사이트는 하나의 세로 흐름으로 읽히는 모바일 우선 랜딩페이지다. 맨 위 히어로는 앱 스토어 소개 이미지와 같은 **하늘빛 그라데이션**(`{gradients.hero}`)으로 시작하고, 그 아래는 흰 캔버스로 내려와 소개 → 익명성 → 기관코드 입력 → 계정 발급 → 앱 설치 순서로 진행한다. 강조가 필요한 섹션만 `{colors.surface}` 또는 `{colors.brand-surface}` 로 바탕을 바꾼다.

색은 두 역할로 나뉜다. **브랜드 블루** `{colors.brand}` 는 실행을 뜻한다 — 채워진 버튼, 포커스 링, 링크. **잉크** `{colors.ink}` 는 모든 본문과 제목이다. 하늘빛 그라데이션과 청록은 **장식 레이어**로만 존재한다: 히어로 배경과 h1 강조 구절.

타이포그래피는 앱의 Pretendard 스케일을 계승하되, 웹 가독성 기준에 맞춰 본문을 앱의 Title 4(18px)로 올려 시작한다. 이 한 줄이 나머지 밀도 결정을 모두 지배한다.

**Key Characteristics:**
- 히어로마다 하늘빛 그라데이션 — 이 그라데이션이 위둘의 얼굴이다.
- h1 안의 한 구절만 `{gradients.heading}` 으로 클립한다. 한 화면에 한 번.
- 단일 CTA 위계: 한 섹션에 채워진 버튼은 하나.
- 본문 18px · 버튼 라벨 20px · 조작 요소 56px — 모든 연령이 첫 시도에 성공하는 것이 목표.
- 3D 캐릭터가 아이콘을 대신한다. 아이콘을 새로 그리지 않는다.
- 익명성이 제품의 핵심 약속이므로 카드로 분리해 눈에 띄게 둔다.
- 발급된 계정은 화면·PNG 두 경로로 제공하며 두 경로의 순서·글자 크기가 같다.

## Colors

전체 팔레트와 대비표는 `tokens.yaml`. 이 문서가 정하는 배치 규칙만 적는다.

- **Brand** `{colors.brand}` — 채워진 버튼, 링크, 포커스 링.
- **Heading Accent** `{colors.heading-accent}` — 섹션 제목(h2) 안의 강조 구절 전용. 3.94:1이므로 24px 이상 Bold에서만. 본문·버튼·링크에는 쓰지 않는다.
- **Hero Backdrop** `{gradients.hero}` — 히어로와 마지막 CTA 밴드, 두 곳까지만. 그 위 글자는 `{colors.ink}` 만(9.9–14.9:1). muted(3.04)·brand(2.67)·흰 글자 금지.
- **H1 Heading Gradient** `{gradients.heading}` — 아래 Signature Components의 세 조건을 모두 만족할 때만.
- 상태색 positive `#2EB8A1`, cautionary `#FFB700` 는 그래프·장식용이며 글자에 쓰지 않는다.

## Typography

스케일은 `tokens.yaml`. 이 문서의 원칙만.

- **본문은 18px 아래로 내려가지 않는다.** 15px 캡션은 푸터·오류 문구·법적 고지에만.
- 한국어 줄바꿈을 관리한다 — 제목 `word-break: keep-all; text-wrap: balance;`, 본문 `text-wrap: pretty;`.
- 숫자에는 `tnum`: 계정 아이디·비밀번호·만료 시각·기관코드.
- 굵기는 400 / 600 / 700 세 단계만.
- **한 화면에 h1은 하나.** 그라데이션 강조도 그 안에서 한 구절만.

## Layout

- 본문 콘텐츠는 `{layout.content-max}` 576px 중앙 정렬. 데스크톱에서도 넓히지 않는다.
- 히어로만 `{layout.hero-max}` 960px 까지 확장해 ≥768px에서 글/이미지 좌우 2단.
- 좌우 여백 모바일 `{layout.gutter-mobile}` 20px.
- 그라데이션 배경은 컨테이너가 아니라 **섹션 전체 폭**(edge-to-edge)에 깐다.
- 섹션 상하 여백 64px(데스크톱 80px). 제목 → 본문 12px · 문단 사이 16px · 본문 → 버튼 24px · 카드 사이 12px.
- 배경색 섹션은 연속 2개 이상 두지 않고, 그라데이션 밴드는 페이지당 최대 2개.

## Elevation & Depth

| Level | Treatment | Use |
|---|---|---|
| 0 | Flat | 기본 표면, 모든 버튼 |
| 1 | `{elevation.card}` | 카드, 계정 발급 상자 |
| 2 | `{elevation.mockup}` | 앱 목업 이미지 |
| 3 | 하늘빛 그라데이션 밴드 | 이 브랜드의 주된 깊이 표현 — 그림자가 아니라 대기감 |

버튼에는 그림자를 쓰지 않는다. 깊이는 색과 여백으로 만든다.

## Shapes

`tokens.yaml`의 `rounded` 를 그대로 쓴다: 버튼·입력 12px, 아이콘 로고 16px, 카드·이미지 20px.
테두리 두께는 기본 1px, 포커스·오류 2px(패딩 1px 보정으로 크기 유지).
사진·목업은 배너 2.17:1, 앱 스크린 약 1:2. 20px 라운드, 테두리 없음.

## Components

### Buttons

**`button-primary`** — 페이지의 주 실행. 섹션당 하나. 높이 56px, 폭 100%(576px 안에서).
- 눌림: 배경 `{colors.brand-strong}`. `transform` 변화 없음, `{motion.button}`.
- 비활성: `{colors.disabled-bg}` / `{colors.disabled-ink}`, `cursor: not-allowed`. 대비 2.50이므로 사유 캡션을 반드시 동반한다.
- 로딩: 스피너 없이 **라벨만 교체**("계정 받기" → "발급 중…") + `aria-busy="true"`.

**`button-secondary`** — 보조 실행(이미지로 저장, 매뉴얼, 스토어). 흰 바탕 + 브랜드 테두리.
- 눌림: 배경 `{colors.brand-surface}`, 글자 `{colors.brand-strong}`(5.89:1).
- 스토어 버튼 2개는 모바일에서도 가로 2열(`1fr 1fr`, gap 12px).

**포커스(공통)**: `{elevation.focus}` 를 `:focus-visible` 로. 제거 금지.

### Inputs & Forms

**`text-input`** — 기관코드. 라벨은 입력창 위 8px에 `{typography.body-strong}`. placeholder를 라벨 대신 쓰지 않는다.
- 포커스: 테두리 2px `{colors.brand}`, 별도 outline 없음.
- 오류: 테두리 2px `{colors.danger}`, 문구는 **입력창 아래 8px**. `aria-invalid="true"` + `aria-describedby`.
- 속성: `inputmode="text" autocapitalize="characters" autocomplete="off"`, `letter-spacing: 0.04em`.

### Cards & Containers

**`card-soft`** — 익명성 조항 등 설명 카드. `{colors.surface}` 바탕, 20px 패딩, 카드 간 12px. 좌측 48px 캐릭터 + 우측 제목(`{typography.subtitle-mobile}`)·설명(`{typography.body}` / `{colors.muted}`).

**`card-outlined`** — 흰 배경 위 강조 블록. 1px `{colors.line}`, 24px 패딩, Level 1 그림자.

**`credential-box`** — 발급된 아이디·비밀번호. 라벨 `{typography.caption}` / `{colors.muted}`, 값 `{typography.credential}` + `tnum`. 사이 1px 구분선. 값 옆 복사 버튼은 48px 이상, 성공 시 "복사했어요"를 문구로 알린다.

**`expiry-band`** — 계정 상자 하단. 문구는 절대시각 `2026년 9월 14일 18:00까지 유효`(상대시간 금지).

### Navigation & Footer

**헤더** — 가로형 로고(28px)만 좌측에 두는 최소 헤더. 배경 투명(히어로 그라데이션 위), 상하 패딩 16px. 메뉴 없음 — 이 사이트는 한 흐름이다.

**`footer`** — `{colors.surface}` 바탕, 위 구분선, 좌측 정렬, 상하 32px. 아이콘 로고 24px → 서비스명 → 문의처 → 개인정보처리방침.

**`link-inline`** — 기본 밑줄 없음, hover에 밑줄 + `{colors.brand-strong}`. 상하 패딩으로 44px 히트영역.

### Signature Components

**Hero Gradient Band** — `{gradients.hero}` 를 섹션 전체 폭에 깐다. 위 글자는 `{colors.ink}` 만. 히어로 위 버튼은 `button-primary` 를 그대로.

**H1 Gradient Phrase** — 앱 브랜드 그라데이션을 h1 안의 한 구절에 클립한다.

```css
.h1-accent {
  color: #0695E4;                      /* 클립 미지원 fallback */
  background: var(--gradient-heading, linear-gradient(115deg, #0695E4 13.67%, #6AF9B9 93.64%));
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
}
```

세 조건을 모두 만족할 때만 쓴다.
1. `{typography.hero-mobile}` 이상(32px+ Bold)에서만. 본문·버튼·h2 금지.
2. h1 전체가 아니라 **강조 구절 하나**에만. 나머지는 `{colors.ink}`.
3. 청록 끝단이 흰 배경 1.32:1이므로 **그 구절이 정보를 단독으로 전달하지 않는다** — 같은 내용이 주변 잉크 글자나 바로 아래 본문에 한 번 더 있어야 한다.

**Character Iconography** — `character/` 3D 캐릭터. mini 48px(카드 아이콘), posture 120–200px(섹션 일러스트), emotion(감정 설명). 아이콘을 새로 그리거나 이모지를 쓰지 않는다.

**Account PNG Export** — 사양은 `tokens.yaml`의 `account-png-export`. 화면과 같은 타입 토큰을 쓰고, 폰트 로드 완료 후 캔버스로 직접 그린다.

## Do's and Don'ts

### Do
- 히어로에 `{gradients.hero}` 를 쓴다. 흰 배경 히어로는 이 버전의 전제에서 벗어난다.
- 채움 버튼은 섹션당 하나.
- 본문 18px · 버튼 20px · 조작 요소 56px 을 지킨다.
- 숫자에 `tnum` 을 건다.
- 아이콘 대신 `character/` 캐릭터를 쓴다.
- 상태는 색과 문구를 함께 써서 알린다.

### Don't
- `{colors.heading-accent}` 를 본문·버튼·링크에 쓰지 않는다(3.94:1).
- h1 그라데이션을 h2 이하·버튼·본문에 쓰지 않는다. 문장 전체를 칠하지 않는다.
- 히어로 그라데이션 위에 muted·brand·흰 글자를 얹지 않는다.
- `{colors.line}` 을 입력창 테두리로 쓰지 않는다 — `{colors.line-control}`.
- 버튼에 그림자나 호버 transform을 넣지 않는다.
- 배경색 섹션을 연속으로 쌓지 않는다.
- 캡션(15px)을 본문 안내 문구로 쓰지 않는다.
- 만료를 상대시간으로 표시하지 않는다.

## Responsive Behavior

| Name | Width | Key Changes |
|---|---|---|
| Mobile | < 768px | 1단, 좌우 20px, 섹션 64px, hero 32px / title 24px |
| Desktop | ≥ 768px | 히어로 960px 2단, 섹션 80px, hero 44px / title 28px / credential 28px |

본문 폭은 두 구간 모두 576px 로 같다. 데스크톱에서 넓어지는 것은 히어로와 여백뿐이다.

### Touch Targets
`tokens.yaml` 기준: 버튼·입력창 56px, 복사 버튼 48px, 인접 간격 12px, 링크 히트영역 44px.

### Collapsing Strategy
- 히어로 2단 → 1단(이미지가 글 아래).
- 스토어 버튼은 모든 폭에서 가로 2열.
- 그라데이션 밴드는 세로 방향 유지(회전·재타일 금지).

### Image Behavior
- 배너: 폭 100%, 비율 유지, `loading="lazy"`.
- 앱 스크린은 이미 그라데이션 배경을 포함하므로 그 섹션 배경은 흰색으로 둔다.
- 캐릭터 PNG는 `width`/`height` 명시로 CLS 방지.

## Iteration Guide

1. 값은 `tokens.yaml` 에서만 고친다. 이 문서에 헥스를 다시 쓰지 않는다.
2. 한 번에 컴포넌트 하나. 토큰 이름으로 지칭한다.
3. 색을 바꾸면 `tokens.yaml` 의 `contrast-ledger` 를 다시 계산한다.
4. 새 변형은 `components:` 의 개별 항목으로 추가한다.
5. 새 색이 필요하면 `Colors.md` 에서 먼저 찾는다.
6. 히어로 그라데이션과 h1 그라데이션은 브랜드 고정값이다 — 재해석하지 않는다.

## Known Gaps

`tokens.yaml` 의 `open-questions` 참조(오류 케이스별 문구, 모션 정책, 다국어, 다크 모드 없음). 이 버전 고유의 미결은 없다.

## 버전 비교

| 버전 | 구조 원본 | 갈라지는 지점 |
|---|---|---|
| **DESIGN.md** (이 문서) | Stripe | 기준 버전. 히어로 그라데이션, 12px 사각 버튼, 틴트 섹션. |
| DESIGN-v2.md | Airbnb | 상태별 컴포넌트를 개별 토큰으로 분리, Known Gaps 상세. |
| DESIGN-v3.md | Figma | 앱 팔레트 50단계로 파스텔 색면 블록 체계. 그라데이션이 블록 패밀리의 첫 장. |
| DESIGN-v4.md | Airtable | **히어로에서 그라데이션 제거** — 계정 발급 단계를 감싸는 시그니처 표면으로 강등. credential 방언. |
| DESIGN-v5.md | MiniMax | 단계별 색 인코딩(STEP 배지), 알약 버튼, 32/16px 라운드 대비, 잉크 반전 푸터. |
