---
version: alpha
name: WeeDool-EAP-web-v3
tokens: ./tokens.yaml
extends: ./tokens.yaml
description: "흰 캔버스와 잉크로 짜인 조용한 안내문 위에, 앱 팔레트에서 뽑아낸 파스텔 색면이 섹션마다 한 장씩 얹히는 시스템. 크롬(헤더·본문·버튼·푸터)은 흰색과 잉크와 브랜드 블루 한 가지로만 움직이고, 이야기가 바뀌는 지점마다 페이지가 통째로 하늘·민트·라벤더·크림 블록으로 넘어간다 — 깨끗한 책상 위에 색지를 한 장씩 올려놓는 방식. 히어로의 하늘빛 그라데이션은 그 블록 체계의 첫 장이자 가장 큰 장이다. 그림자 대신 색면이 깊이를 만들고, 본문의 강약은 색이 아니라 굵기가 만든다."

overrides:
  rounded:
    block: 28px          # 색면 블록 전용 라운드
  typography:
    eyebrow: { size: 15px, weight: 700, line: 1.3, tracking: 0.9px, transform: uppercase }
    subhead: { size: 24px, weight: 400, line: 1.45, tracking: -0.24px }   # 블록 안 도입 문장
  # 이유: 블록 체계에는 (a) 분류 라벨과 (b) 제목보다 가볍고 본문보다 큰 도입 문장이 필요하다.
  #       기본 스케일에는 둘 다 없다.

components:
  eyebrow-label:
    textColor: "{colors.muted}"
    typography: "{overrides.typography.eyebrow}"
    marginBottom: "{spacing.md}"
  block-hero:
    background: "{gradients.hero}"
    textColor: "{colors.ink}"
    rounded: 0
    padding: "{spacing.section} {spacing.lg}"
  block-sky:
    backgroundColor: "{colors.block-sky}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.block}"
    padding: "{spacing.huge} {spacing.xl}"
  block-mint:
    backgroundColor: "{colors.block-mint}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.block}"
    padding: "{spacing.huge} {spacing.xl}"
  block-lilac:
    backgroundColor: "{colors.block-lilac}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.block}"
    padding: "{spacing.huge} {spacing.xl}"
  block-cream:
    backgroundColor: "{colors.block-cream}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.block}"
    padding: "{spacing.huge} {spacing.xl}"
  block-paper:
    backgroundColor: "{colors.block-paper}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.block}"
    padding: "{spacing.huge} {spacing.xl}"
  block-ink:
    backgroundColor: "{colors.surface-dark}"
    textColor: "{colors.canvas}"
    rounded: "{overrides.rounded.block}"
    padding: "{spacing.huge} {spacing.xl}"
  section-canvas:
    backgroundColor: "{colors.canvas}"
    padding: "{spacing.section} {spacing.lg}"
    maxWidth: "{layout.content-max}"
  button-primary:
    backgroundColor: "{colors.brand}"
    textColor: "{colors.on-brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 24px"
    width: 100%
  button-primary-pressed:
    backgroundColor: "{colors.brand-strong}"
  button-primary-disabled:
    backgroundColor: "{colors.disabled-bg}"
    textColor: "{colors.disabled-ink}"
  button-secondary:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
  button-on-block:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
  button-icon-square:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    size: "{layout.icon-button}"
  card-on-block:
    backgroundColor: "{colors.canvas}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
    iconSize: 48px
    shadow: none
  card-outlined:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
  credential-box:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    valueTypography: "{typography.credential}"
    labelTypography: "{typography.caption}"
    labelColor: "{colors.muted}"
  credential-expiry-band:
    backgroundColor: "{colors.block-cream}"
    textColor: "{colors.warning}"
    typography: "{typography.caption-strong}"
    padding: "14px {spacing.xl}"
  text-input:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line-control}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 16px"
    typography: "{typography.body}"
  text-input-focused:
    border: "2px solid {colors.brand}"
  text-input-error:
    border: "2px solid {colors.danger}"
  app-mockup:
    rounded: "{rounded.lg}"
    shadow: "{elevation.mockup}"
  qr-plate:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    padding: "{spacing.md}"
    size: 160px
  check-glyph:
    textColor: "{colors.success}"
    size: 20px
  top-header:
    backgroundColor: transparent
    logoHeight: 28px
    height: 60px
  footer:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.muted}"
    typography: "{typography.caption}"
    borderTop: "1px solid {colors.line}"
    padding: "{spacing.xxl} {spacing.lg}"
---

## Overview

크롬은 **흰 종이**다. 헤더, 본문, 버튼, 푸터 — 전부 흰 캔버스 위 잉크와 브랜드 블루 한 가지로만 움직인다. 중간 회색 글자를 위계에 쓰지 않고, 굵기(400 / 600 / 700)가 위계를 만든다.

흥미로워지는 지점은 그 사이다. 이야기가 바뀔 때마다 페이지가 통째로 **파스텔 색면 블록**으로 넘어간다 — 하늘·민트·라벤더·크림, 그리고 드물게 잉크. 모두 앱 팔레트(`Colors.md`)의 50단계 틴트에서 그대로 가져온 색이라 새 색을 발명하지 않았다. 블록은 카드 안에 들어간 강조색이 아니라 **한 화면 분량의 세로 공간을 차지하는 색지**다.

이 블록 체계의 첫 장이자 가장 큰 장이 **히어로 그라데이션**이다. 다른 블록이 단색 색지라면 히어로는 하늘이 내려앉는 색지다. 페이지에서 유일하게 그라데이션이 배경으로 쓰이는 곳이기도 하다.

대비의 시스템이다. 흰 크롬이 색면을 의도적으로 보이게 만들고, 색면이 흰 크롬을 기업용 SaaS가 아니라 편집된 안내문처럼 보이게 만든다.

**Key Characteristics:**
- 단색 코어(잉크 + 흰색 + 브랜드 블루)가 모든 CTA·본문·링크를 담당.
- 섹션 서사를 색면 블록이 만든다. 블록 사이에는 반드시 흰 캔버스가 한 번 들어간다.
- 앱 팔레트 50단계에서만 블록 색을 뽑는다.
- 버튼은 12px 라운드 사각형 하나뿐 — 알약도 원형도 쓰지 않는다.
- 본문의 강약은 색이 아니라 굵기가 만든다(흐린 글자는 이 사용자층에서 곧바로 읽기 실패가 된다).
- 아이콘을 그리지 않는다. `character/` 3D 캐릭터가 대신한다.
- 그림자는 앱 목업 한 곳에만. 깊이는 색면이 만든다.

## Colors

팔레트·대비표는 `tokens.yaml`. 이 버전의 블록 배치:

| 블록 | 토큰 | 출처 | 쓰는 곳 |
|---|---|---|---|
| Hero | `{gradients.hero}` | 브랜드 고정 | 히어로. 라운드 없이 화면 전체 폭 |
| Mint | `{colors.block-mint}` | Caribbean Green 50 | 익명성·안심 서사 |
| Sky | `{colors.block-sky}` | Primary 50 | 계정 발급 단계, 마지막 CTA |
| Lilac | `{colors.block-lilac}` | Majorelle 50 | 앱 기능 소개 |
| Cream | `{colors.block-cream}` | Selective Yellow 50 | 주의·만료 안내 |
| Paper | `{colors.block-paper}` | — | 색을 쓰고 싶지 않은 중립 블록 |
| Ink | `{colors.surface-dark}` | — | 반전 블록. **페이지당 한 번만** |

모든 밝은 블록 위 잉크 글자는 15:1 이상이다. 히어로 그라데이션 위에서는 muted(3.04)·brand(2.67)·흰 글자 금지 — 잉크만.

`{colors.muted}` 는 아이브로우·캡션·푸터에만 쓴다. **본문 위계용으로 쓰지 않는다.**

## Typography

스케일은 `tokens.yaml`. 이 버전이 추가하는 두 토큰:

- `{overrides.typography.eyebrow}` — 15px/700, 0.9px 양수 자간, 대문자. 블록 제목 위 분류 라벨.
- `{overrides.typography.subhead}` — 24px/400. 제목보다 가볍고 본문보다 큰 도입 문장. 블록 안에서만 쓴다.

원칙:
- **본문의 강약은 굵기가 만든다.** 18px/400 옆의 18px/600 — 크기를 바꾸지 않고 강조한다.
- 음수 자간은 크기에 비례하되 -0.02em을 넘기지 않는다(한글 받침).
- **아이브로우 대문자 조판은 한글에 쓰지 않는다.** `ANONYMITY`, `STEP 02` 같은 라틴·숫자 라벨 전용이며, 한글 라벨이 필요하면 `{typography.caption-strong}` 으로 대체한다.
- 디스플레이는 촘촘하게(1.25–1.35), 본문은 넉넉하게(1.6).
- 본문 18px 하한. 15px은 아이브로우·캡션·오류 문구 세 곳만.

## Layout

`tokens.yaml`의 `layout` 기준. 이 버전의 구조 규칙:

- **색면 블록은 컨테이너를 깬다**: 블록 자체는 좌우 20px 여백 안에서 화면 폭을 채우고(28px 라운드), 그 안의 글은 다시 576px 컬럼으로 들어간다. 히어로 블록만 라운드 없이 화면 끝까지.
- 블록 내부 패딩 상하 48px · 좌우 24px.
- 블록과 블록 사이에는 흰 캔버스가 64px 이상 들어간다.
- **한 뷰포트 안에 색면 두 개가 동시에 보이면 색지가 아니라 벽지가 된다** — 그 순간 시스템이 무너진다.

블록 안 구성 순서: `eyebrow-label` → 제목(`{typography.title-desktop}`) → `subhead` 또는 본문 → (선택) 버튼 하나.

## Elevation & Depth

| Level | Treatment | Use |
|---|---|---|
| 0 (평면) | 그림자·테두리 없음 | 색면 블록, 히어로, 모든 버튼, 푸터 — 표면의 90% |
| 1 (헤어라인) | 1px `{colors.line}` | 카드, 계정 상자, QR 판 |
| 2 (부양) | `{elevation.mockup}` | 앱 스크린 목업 — 유일한 실제 그림자 |
| 3 (모달) | Level 2 + `{elevation.scrim}` | 매뉴얼 미리보기 등 |

그림자를 아끼는 이유는 색면이 이미 깊이를 만들기 때문이다. 그래서 앱 목업 하나에만 걸린 그림자가 "여기는 실제 제품 화면" 이라는 신호로 읽힌다.

캐릭터 PNG는 투명 배경 그대로 얹는다. 원형 배경판이나 그림자를 넣지 않는다 — 캐릭터 자체에 이미 입체가 들어 있다.

## Shapes

`tokens.yaml`의 `rounded` + 이 버전의 `block` 28px.

하드 코너는 저장용 PNG 한 곳뿐이다. 버튼은 **알약이 아니다** — 12px 라운드 사각형이 폭 100%로 놓였을 때 가장 "눌러도 되는 것"으로 읽히고, 56px 높이와도 비례가 맞는다.

## Components

### Buttons
- **`button-primary`** — 한 뷰포트에 둘 이상 두지 않는다. 눌림에서 `transform` 변화 없음.
- **로딩** — 스피너 없이 라벨만 "발급 중…" + `aria-busy="true"`.
- **`button-primary-disabled`** — 2.50:1이므로 사유 캡션을 반드시 동반.
- **`button-on-block`** — 색면 블록 **위**에 놓이는 버튼. secondary와 같은 사양(흰 바탕 + 브랜드 테두리)을 쓴다. 블록 위에서는 흰 면이 가장 강한 도형이므로 채움 버튼을 또 쓸 필요가 없다. **히어로 그라데이션 위에서만 예외적으로 `button-primary`.** 잉크 블록 위에서는 테두리·글자를 흰색으로 반전.
- **`button-icon-square`** — 48×48px 복사 버튼. 성공 시 "복사했어요" 를 문구로.
- 포커스: `{elevation.focus}`. 모든 블록이 밝아 블루 링이 살아 있다.

### Color-Block Sections (signature)
표 참조(Colors). 각 블록은 좌우 20px 여백 안에서 화면 폭을 채우고 28px 라운드, 내부 상하 48px.

**`block-ink`** 는 페이지당 한 번만. 흰 글자, 내부 버튼은 테두리·글자를 흰색으로 반전.

### Cards
- **`card-on-block`** — 색면 블록 **안**에 놓이는 흰 카드. 테두리도 그림자도 없다 — 색 대비가 이미 분리를 만든다. 좌측 48px 캐릭터 + 우측 제목·설명, 카드 사이 12px.
- **`card-outlined`** — 흰 캔버스 위 카드. 1px `{colors.line}`, 그림자 없음.

### Credential
- **`credential-box`** — `{components.block-sky}` 안에 놓는다. 페이지에서 가장 중요한 흰 면이 가장 또렷한 배경 위에 앉는다.
- **`credential-expiry-band`** — 크림 띠. 절대시각 표기, 상대시간 금지.
- PNG 저장은 `tokens.yaml`의 `account-png-export`.

### Forms
- **`text-input`** — 라벨은 위 8px에 `{typography.body-strong}`. 오류는 테두리 + 아래 문구 한 쌍.
- **색면 블록 위에서도 배경은 흰색을 유지한다.** 블록색 입력창 금지 — 입력 가능한 면은 항상 흰색이다.

### Media & Glyphs
- **`app-mockup`** — 이미지 자체가 그라데이션 배경을 포함하므로 **그 섹션 바탕은 흰색**으로 둔다(그라데이션 두 겹 금지).
- **`qr-plate`** — 160px, 아래 캡션 "카메라로 스캔하세요".
- **캐릭터** — mini 48px, posture 120–200px, emotion. 아이콘을 새로 그리거나 이모지를 쓰지 않는다.
- **`check-glyph`** — `{colors.success}`. 면색이 아니라 글리프 색으로만.

### Navigation & Footer
- **`top-header`** — 투명 바(히어로 그라데이션 위에 겹침), 로고 28px만. 메뉴 없음.
- **`footer`** — 흰 캔버스(색면 아님), 위 1px 구분선, 좌측 정렬.

## Do's and Don'ts

### Do
- 새 섹션을 만들 때 **먼저 어떤 블록 위에 앉을지** 정한다. 표면 선택이 가장 큰 결정이다.
- 블록과 블록 사이에 흰 캔버스를 반드시 넣는다.
- 블록 위 버튼은 `button-on-block`.
- 본문 강조는 굵기 600으로.
- 블록 안에 놓는 카드는 흰색으로 둔다.
- 새 색이 필요하면 `Colors.md` 50단계에서 찾는다.

### Don't
- 한 뷰포트에 색면 블록 두 개가 동시에 보이게 하지 않는다.
- `block-ink` 를 페이지에 두 번 쓰지 않는다.
- 히어로 그라데이션 위에 muted·brand·흰 글자를 얹지 않는다.
- 중간 회색으로 본문 위계를 만들지 않는다.
- 색면 블록에 그림자를 넣지 않는다 — 색이 곧 깊이다.
- 버튼을 알약이나 정사각으로 만들지 않는다.
- 아이브로우 대문자 조판을 한글에 쓰지 않는다.
- 목업이 있는 섹션에 색면을 깔지 않는다.

## Responsive Behavior

| Name | Width | Key Changes |
|---|---|---|
| Mobile | < 768px | 1단, 좌우 20px, 섹션 64px, hero 32px / 블록 제목 28px. **색면 블록은 라운드를 버리고 full-bleed**(포스터 효과). |
| Desktop | ≥ 768px | 히어로만 960px 2단, 섹션 80px, hero 44px. 색면 블록은 좌우 20px 여백 안에서 28px 라운드 유지. 본문 576px 그대로. |

### Touch Targets
버튼·입력창 56px, 복사 버튼 48px, 인접 간격 12px, 링크 히트영역 44px.

### Collapsing
- 히어로 2단 → 1단.
- 색면 블록: 라운드 → full-bleed. 이 전환이 모바일에서 블록을 더 강하게 만든다.
- 스토어 버튼 쌍은 모든 폭에서 가로 2열.
- 히어로 그라데이션은 세로 방향 유지.

## Iteration Guide

1. 값은 `tokens.yaml` 에서만.
2. 새 섹션은 **표면부터** 정한다 — 흰 캔버스인가, 어떤 블록인가.
3. `{colors.brand}` 를 아낀다. 한 뷰포트에 채움 버튼이 둘이면 하나를 `button-on-block` 으로 내린다.
4. 블록 색을 추가하려면 `Colors.md` 의 50단계에서 고른다. 새 색상군을 만들지 않는다.
5. 새 변형은 `components:` 항목으로.

## Known Gaps

- **모노 패밀리 없음.** 아이브로우·캡션을 모노로 조판하는 원본 시스템과 달리 이 브랜드에는 모노 글꼴이 없다. Pretendard 700 + 양수 자간으로 대체했고, 한글 아이브로우는 사실상 포기했다(캡션 600으로 대체).
- **`block-ink` 실사용처 미정.** 사양은 있으나 "안심" 정서와 충돌할 수 있어 어느 섹션에도 배정하지 않았다.
- **블록 순서(색 리듬) 미확정.** 현재 제안: 히어로 그라데이션 → 흰 캔버스(소개) → 민트(익명성) → 흰 캔버스(목업) → 스카이(계정 발급) → 흰 캔버스(앱 설치) → 푸터.
- 그 외는 `tokens.yaml` 의 `open-questions`.
