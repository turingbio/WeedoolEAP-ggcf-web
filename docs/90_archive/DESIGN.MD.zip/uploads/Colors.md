# Colors

## Neutral

### Cool Neutral

Cool Neutral 1: #F7F7F8
Cool Neutral 5: #F4F4F5
Cool Neutral 10: #EAEBEC
Cool Neutral 20: #E1E2E4
Cool Neutral 30: #DBDCDF
Cool Neutral 40: #C2C4C8
Cool Neutral 50: #AEB0B6
Cool Neutral 60: #989BA2
Cool Neutral 70: #878A93
Cool Neutral 80: #70737C
Cool Neutral 90: #5A5C63
Cool Neutral 100: #46474C
Cool Neutral 200: #37383C
Cool Neutral 300: #333438
Cool Neutral 400: #2E2F33
Cool Neutral 500: #292A2D
Cool Neutral 600: #212225
Cool Neutral 800: #171719

---

## Semetic

### Static

Black: #000000
White: #FFFFFF

### Label

secondary: #1D1F27
primary: #5A5C63
teriary: #878A93
Strong: #000000
Disable: #DFDFE0
Assistive: #AEB0B6

### Primary

light: #4C94FF
Normal: #008EFF
Strong: #0079FF
Heavy: #0066FF

### Line

Normal: 70737C38
Alternative: 70737C14
Neutral: 70737C29

### Interaction

Disable: #F1F4FF
Inactive: #999CA5

### Background

Alternative: #F8F8FA
Normal: #FFFFFF
Elevated: #EDF3FA
Muted: #FAFAFA

### Status

Positive: #2EB8A1
Negative: #F64C4C
Cautionary: #FFB700

### Dimmer

Dimmer: #1717198C

### Fill

Alternative: #70737C0D
Strong: #70737C29
Normal: #70737C14

---

## Palette

### Primary

50: #E5EFFF
100: #CCE0FF
200: #99C2FF
300: #7FB2FF
400: #4C94FF
500: #1A75FF
600: #0066FF
700: #0052CC
800: #003D99
900: #002966

### Error

50: #FEE7E7
100: #FCCFCF
200: #FA9E9E
300: #F98686
400: #F98686
500: #F64C4C
600: #F20D0D
700: #C20A0A
800: #910808
900: #610505

### Neutral Gray

50: #F9FAFB
100: #F2F4F7
200: #E4E7EC
300: #CED2DA
400: #97A1AF
500: #637083
600: #414E62
700: #344051
800: #202B37
900: #141C24

### Grey Cold

50: #F1F3F4
100: #E4E7E8
200: #C7CED1
300: #B9C2C6
400: #ABB6BB
500: #8F9CA3
600: #73848C
700: #5C6970
800: #454F54
900: #2E3538

### Caribbean Green

50: #EBFAF7
100: #D6F5F0
200: #ADEBE0
300: #99E6D9
400: #85E0D1
500: #33CCB2
600: #2EB8A1
700: #29A38F
800: #0B8E78
900: #145247

### Majorelle Blue

50: #ECE9FB
100: #DAD4F7
200: #B4A8F0
300: #A193EC
400: #8F7DE8
500: #6952E0
600: #4426D9
700: #361FAD
800: #291782
900: #1B0F57

### Red Crayola

50: #FCE8EC
100: #F9D2D9
200: #F4A4B3
300: #F18EA0
400: #EE778D
500: #E94967
600: #E31C41
700: #B61634
800: #881127
900: #5B0B1A

### Mandarin Orange

50: #FDEDE7
100: #FCDCCF
200: #F9B99F
300: #F7A787
400: #F6956F
500: #F3733F
600: #F04F0F
700: #C03F0C
800: #902F09
900: #602006

### Selective Yellow

50: #FEF7E6
100: #FDF0CE
200: #FCE19C
300: #FCDA83
400: #FBD26A
500: #FFB700
600: #EBA800
700: #CC9200
800: #996E00
900: #664900
