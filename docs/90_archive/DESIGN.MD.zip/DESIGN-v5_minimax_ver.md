---
version: alpha
name: WeeDool-EAP-web-v5
tokens: ./tokens.yaml   # 색·타입·간격·대비표는 전부 여기. 이 문서는 구조와 배치만 다룬다.
description: 흰 캔버스와 브랜드 블루 알약 CTA로 짜인 안내 프레임을, 단계마다 하나씩 놓인 채도 높은 풀컬러 카드가 끊는다. 이 페이지의 "제품"은 모델이 아니라 **단계**다 — 익명성, 계정 발급, 앱 설치. 각 단계가 자기 색을 갖고(민트·그라데이션·블루), 앨범 커버처럼 세로로 쌓인다. 활자는 Pretendard 하나, 히어로는 큰 크기와 촘촘한 행간으로 밀어붙이되 본문은 18px 아래로 내려가지 않는다. 알약 버튼과 28px 라운드 카드가 이 버전의 서명이다.

extends: ./tokens.yaml
overrides:
  rounded:
    button: 9999px        # 이 버전만 알약. 다른 버전은 12px 사각형.
    card-vivid: 32px      # 풀컬러 단계 카드
    card-quiet: 16px      # 흰 보조 카드
  typography:
    hero-mobile:  { size: 40px, weight: 700, line: 1.15, tracking: -1.2px }
    hero-desktop: { size: 64px, weight: 700, line: 1.10, tracking: -2px }

components:
  promo-banner:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.canvas}"
    typography: "{typography.caption-strong}"
    padding: "{spacing.md} {spacing.lg}"
  top-nav:
    backgroundColor: "{colors.canvas}"
    borderBottom: "1px solid {colors.line}"
    logoHeight: 28px
    height: 64px
  hero-band:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.ink}"
    typography: "{overrides.typography.hero-mobile}"
    padding: "{spacing.huge} {spacing.lg}"
  button-primary:
    backgroundColor: "{colors.brand}"
    textColor: "{colors.on-brand}"
    typography: "{typography.button}"
    rounded: "{overrides.rounded.button}"
    padding: "0 32px"
    height: "{layout.control-height}"
  button-primary-pressed:
    backgroundColor: "{colors.brand-strong}"
  button-primary-disabled:
    backgroundColor: "{colors.disabled-bg}"
    textColor: "{colors.disabled-ink}"
  button-secondary:
    backgroundColor: transparent
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    typography: "{typography.button}"
    rounded: "{overrides.rounded.button}"
    height: "{layout.control-height}"
  button-on-vivid:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.ink}"
    typography: "{typography.button}"
    rounded: "{overrides.rounded.button}"
    height: "{layout.control-height}"
  button-icon-circular:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.full}"
    size: "{layout.icon-button}"
  step-card-mint:
    backgroundColor: "{colors.vivid-teal}"
    textColor: "{colors.canvas}"
    rounded: "{overrides.rounded.card-vivid}"
    padding: "{spacing.huge} {spacing.xl}"
  step-card-issue:
    background: "{gradients.hero}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.card-vivid}"
    padding: "{spacing.huge} {spacing.xl}"
  step-card-blue:
    backgroundColor: "{colors.vivid-blue}"
    textColor: "{colors.canvas}"
    rounded: "{overrides.rounded.card-vivid}"
    padding: "{spacing.huge} {spacing.xl}"
  step-card-ink:
    backgroundColor: "{colors.vivid-ink}"
    textColor: "{colors.canvas}"
    rounded: "{overrides.rounded.card-vivid}"
    padding: "{spacing.huge} {spacing.xl}"
  quiet-card:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{overrides.rounded.card-quiet}"
    padding: "{spacing.lg}"
  credential-card:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.xl}"
    valueTypography: "{typography.credential-lg}"
  credential-expiry-row:
    backgroundColor: "{colors.warning-surface}"
    textColor: "{colors.warning}"
    typography: "{typography.caption-strong}"
    padding: "14px {spacing.xl}"
  text-input:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line-control}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 16px"
    typography: "{typography.body}"
  text-input-focused:
    border: "2px solid {colors.brand}"
  text-input-error:
    border: "2px solid {colors.danger}"
  badge-step:
    backgroundColor: "rgba(255,255,255,0.22)"
    textColor: "{colors.canvas}"
    typography: "{typography.caption-strong}"
    rounded: "{rounded.full}"
    padding: "4px 12px"
  badge-step-on-light:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.ink}"
    typography: "{typography.caption-strong}"
    rounded: "{rounded.full}"
    padding: "4px 12px"
  qr-plate:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    padding: "{spacing.md}"
    size: 160px
  footer-region:
    backgroundColor: "{colors.surface-dark}"
    textColor: "{colors.canvas}"
    typography: "{typography.caption}"
    padding: "{spacing.xxl} {spacing.lg}"
---

## Overview

위둘 EAP 안내 페이지는 흰 캔버스와 잉크 활자로 된 조용한 프레임이지만, **단계마다 한 장씩 놓인 채도 높은 풀컬러 카드**가 그 프레임을 끊는다. MiniMax가 모델 하나하나에 색을 주듯, 이 페이지는 **단계**에 색을 준다 — 익명성은 딥 틸, 계정 발급은 브랜드 그라데이션, 앱 설치는 브랜드 블루. 세 장이 세로로 쌓여 앨범 커버처럼 읽힌다.

이 배치의 이유는 정서가 아니라 구조다. 이 페이지는 스크롤 한 번에 세 가지 일을 시켜야 하고(익명성 이해 → 코드 입력 → 앱 설치), 흰 캔버스만으로는 "내가 몇 번째 단계인지" 가 보이지 않는다. 색 카드가 진행 표시기를 대신한다. 그래서 각 카드 좌상단에 `STEP 01 / 02 / 03` 배지가 붙는다 — 이 버전에만 있는 요소다.

활자는 Pretendard 하나. 히어로는 크기와 촘촘한 행간(1.15, -1.2px)으로 밀어붙이지만, 본문은 18px/1.6 아래로 내려가지 않는다. MiniMax의 14px 본문은 이 사용자층에 그대로 옮길 수 없다 — 문서 밀도를 포기하고 첫 시도 성공률을 산다.

**버튼은 이 버전에서만 알약이다.** 다른 버전(v1–v4)은 12px 라운드 사각형을 쓴다. 알약 + 32px 라운드 풀컬러 카드 + 16px 흰 카드, 이 세 라운드의 대비가 v5의 시각 서명이다.

**Key Characteristics:**
- 단색 프레임(`{colors.canvas}` + `{colors.ink}`)을 채도 높은 단계 카드가 끊는다.
- 단계별 색 인코딩: 익명성=`{colors.vivid-teal}`, 계정 발급=`{gradients.hero}`, 앱 설치=`{colors.vivid-blue}`. **자유 선택이 아니라 배정이다.**
- 모든 버튼·배지가 알약(`{overrides.rounded.button}`). 사각은 입력창과 QR 판에만.
- 풀컬러 카드 32px / 흰 카드 16px — 같은 화면에 두 라운드를 함께 둔다.
- 히어로 40px(모바일) / 64px(데스크톱), 행간 1.10–1.15, 음수 자간.
- 페이지 상단에 잉크 프로모 띠(선택) — 기관 공지·마감 안내용.
- 푸터는 잉크 반전. 이 페이지에서 흰 캔버스가 아닌 유일한 전면 표면(단계 카드 제외).

## Colors

전체 팔레트·대비표는 `tokens.yaml`. 이 버전이 추가로 정하는 것만 적는다.

### 단계 색 배정 (Step Color Encoding)
| 단계 | 표면 | 글자 | 흰 글자 대비 |
|---|---|---|---|
| STEP 01 · 익명성 | `{colors.vivid-teal}` #145247 | `{colors.canvas}` | 9.02 ✅ |
| STEP 02 · 계정 발급 | `{gradients.hero}` | **`{colors.ink}`** | 9.88–14.9 ✅ |
| STEP 03 · 앱 설치 | `{colors.vivid-blue}` #0066FF | `{colors.canvas}` | 4.83 ✅ |
| (예비) 문의·안내 | `{colors.vivid-violet}` #361FAD | `{colors.canvas}` | 10.73 ✅ |

- **그라데이션 카드만 잉크 글자를 쓴다.** 밝은 표면이기 때문이다. 나머지 단계 카드는 흰 글자.
- 단계 색은 **단계 정체성 전용**이다. 일반 버튼·본문·아이콘에 쓰지 않는다. `{colors.vivid-teal}`을 버튼 배경에 쓰는 순간 단계 인코딩이 무너진다.
- `{colors.vivid-blue}`는 `{colors.brand}`와 같은 값이다. STEP 03 카드 위에서는 CTA가 `button-on-vivid`(흰 알약)로 바뀌므로 충돌하지 않는다.

### 이 버전의 금지 조합
- 단계 카드 위 `{colors.muted}` — 어떤 단계 색 위에서도 대비 미달.
- 그라데이션 카드 위 흰 글자·`{colors.brand}` (2.67–3.04).
- 잉크 푸터 위 `{colors.muted}` — 푸터 글자는 흰색 또는 rgba(255,255,255,0.72) 이상.

## Typography

전체 스케일은 `tokens.yaml`. 이 버전의 오버라이드와 원칙만.

### Overrides
| Token | v5 값 | 기본값(tokens.yaml) |
|---|---|---|
| hero-mobile | 40px / 700 / 1.15 / -1.2px | 32px / 1.30 / -0.64px |
| hero-desktop | 64px / 700 / 1.10 / -2px | 44px / 1.25 / -0.88px |

히어로를 키운 이유: 이 버전은 히어로에 장식을 넣지 않고(배경 흰색) 활자 하나로 첫 화면을 세운다. 대신 **한글에서 -2px는 과하다** — 64px 기준 -0.03em이므로, 실제로는 `-0.02em`(≈-1.28px)으로 클램프하고 문서에는 상한만 남긴다.

### 이 버전의 원칙
- 단계 카드 안 제목은 `{typography.title-desktop}`(28px/700), 설명은 `{typography.body}`(18px/400). 카드 안에서 본문을 줄이지 않는다.
- `STEP 01` 배지는 `{typography.caption-strong}` + 대문자 + 0.9px 양수 자간. 라틴·숫자 조합이므로 대문자 조판이 성립한다.
- 계정 값만 `{typography.credential-lg}`(28px + tnum + 양수 자간). 페이지에서 유일한 양수 자간 본문.
- 본문 18px 하한은 오버라이드 대상이 아니다.

## Layout

`tokens.yaml`의 `layout` 을 그대로 쓴다(본문 576px, 히어로 960px, 좌우 20px, 조작 요소 56px).

### 이 버전의 구조
- **세로 스택 단 하나.** 단계 카드는 캐러셀이나 가로 스크롤이 아니다 — 순서가 의미를 갖기 때문에 반드시 위에서 아래로 쌓는다.
- 단계 카드는 좌우 20px 여백 안에서 화면 폭을 채우고, 안쪽 콘텐츠는 다시 576px.
- 카드 안 구성: `badge-step` → 제목 → 설명 → (선택) 흰 보조 카드 또는 버튼 하나.
- 단계 카드 사이에는 흰 캔버스가 `{spacing.section}`(64px) 들어간다. **카드 두 장을 붙이지 않는다.**

### Whitespace
히어로 위아래 48px, 섹션 간 64px(데스크톱 80px), 카드 내부 상하 48px. 단계 카드 안에서는 요소 간 20px로 촘촘하게 — 밖은 넓고 안은 좁은 리듬이 카드를 하나의 덩어리로 읽히게 한다.

## Elevation & Depth

| Level | Treatment | Use |
|---|---|---|
| 0 | 그림자 없음 | 단계 카드, 버튼, 히어로, 푸터 |
| 1 | `{elevation.card}` | 흰 보조 카드, 계정 상자 |
| 2 | `{elevation.mockup}` | 앱 스크린 목업 |
| Focus | `{elevation.focus}` | 모든 조작 요소 `:focus-visible` |

단계 카드에 그림자를 넣지 않는다 — 채도가 이미 깊이를 만든다. 카드 위에 놓인 흰 보조 카드도 그림자 없이 색 대비만으로 분리된다.

## Components

> 호버는 문서화하지 않는다. Default / Pressed / Disabled / Error만.

### Buttons

**`button-primary`** — 브랜드 블루 알약. 좌우 32px, 높이 56px, 폭 100%(576px 안에서). 뷰포트당 하나.
- Pressed: `{colors.brand-strong}`. Disabled: `{colors.disabled-bg}` / `{colors.disabled-ink}` + 사유 캡션 필수.
- Loading: 스피너 없이 라벨만 "발급 중…" + `aria-busy="true"`.

**`button-secondary`** — 투명 바탕 + 브랜드 테두리 알약. 히어로에서 primary와 한 쌍.

**`button-on-vivid`** — 채도 카드 위 CTA. **흰 알약 + 잉크 글자.** 단계 카드 위에서는 브랜드 블루 채움을 쓰지 않는다(파랑 위 파랑, 틸 위 파랑 모두 읽히지 않는다). 그라데이션 카드 위에서만 예외적으로 `button-primary` 를 쓴다 — 밝은 표면이라 파랑이 살아 있다.

**`button-icon-circular`** — 계정 값 옆 복사 버튼. 48px 원형, 1px `{colors.line}`. 이 버전에서만 원형(다른 버전은 사각) — 알약 언어와 맞춘다. 성공 시 "복사했어요" 를 문구로.

### Step Cards (signature)

각 카드는 32px 라운드, 상하 48px · 좌우 24px 패딩, 그림자 없음.

**`step-card-mint`** — STEP 01 익명성. `{colors.vivid-teal}` 바탕 + 흰 글자. 안에 흰 `quiet-card` 3장(캐릭터 48px + 제목 + 설명)을 12px 간격으로. 이 페이지의 핵심 약속이므로 첫 카드다.

**`step-card-issue`** — STEP 02 계정 발급. `{gradients.hero}` 바탕 + **잉크 글자**. 기관코드 입력창과 발급된 계정 카드가 여기 들어간다. 페이지에서 유일한 그라데이션 표면.

**`step-card-blue`** — STEP 03 앱 설치. `{colors.vivid-blue}` 바탕 + 흰 글자. QR 판 2개(흰 바탕)와 스토어 버튼 쌍(`button-on-vivid`).

**`step-card-ink`** — 예비. 문의·긴급 연락 안내용으로 정의만 해둔다(→ Known Gaps).

**`badge-step`** — 카드 좌상단 `STEP 01`. 어두운 카드 위에서는 반투명 흰 바탕(`rgba(255,255,255,0.22)`) + 흰 글자, 그라데이션 카드 위에서는 `badge-step-on-light`(흰 바탕 + 잉크 글자).

### Quiet Cards

**`quiet-card`** — 단계 카드 안에 놓이는 흰 카드. **16px 라운드** — 바깥 32px과 짝을 이루는 라운드 대비가 이 버전의 시각 서명이다. 1px `{colors.line}`, 20px 패딩.

### Credential

**`credential-card`** — 흰 바탕, 20px 라운드, 24px 패딩, 1px `{colors.line}`. 값은 `{typography.credential-lg}`(28px + tnum). `step-card-issue` 안에 놓인다.

**`credential-expiry-row`** — 하단 크림 줄, `{colors.warning}` 600. 문구는 절대시각(`2026년 9월 14일 18:00까지 유효`). 상대시간 금지.

PNG 저장 사양은 `tokens.yaml`의 `account-png-export` 를 따른다. 단, 이 버전에서는 저장 이미지 안의 값도 28px(`credential-lg`)로 맞춘다.

### Forms

**`text-input`** — 기관코드. 12px 라운드(알약 아님 — 입력창을 알약으로 만들면 커서 위치가 모호해진다), 56px 높이, 1px `{colors.line-control}`. Focus 2px `{colors.brand}`, Error 2px `{colors.danger}` + 아래 8px 문구. 그라데이션 카드 위에서도 배경은 흰색.

### Navigation & Footer

**`promo-banner`** — 상단 잉크 띠. 기관 공지·신청 마감 같은 기한성 문구 한 줄. 선택 요소이며, 없을 때가 기본이다.

**`top-nav`** — 흰 바 64px, 가로형 로고 28px만. 메뉴 없음.

**`footer-region`** — **잉크 반전 푸터.** `{colors.surface-dark}` 바탕 + 흰 글자, 상하 32px. 아이콘 로고 24px → 서비스명 → 문의처 → 개인정보처리방침. 링크는 흰색 + 밑줄(파란 링크를 어두운 바탕에 쓰지 않는다 — 대비 2.5:1).

## Do's and Don'ts

### Do
- 단계 색 배정을 지킨다: 익명성=틸, 발급=그라데이션, 설치=블루.
- 채도 카드 위 CTA는 흰 알약(`button-on-vivid`). 그라데이션 카드에서만 브랜드 채움.
- 32px 카드와 16px 카드를 같은 화면에 둔다 — 라운드 대비가 서명이다.
- 모든 버튼·배지를 알약으로. 입력창과 QR 판만 사각.
- 단계 카드 사이에 흰 캔버스를 64px 넣는다.
- 히어로는 활자로 세운다 — 배경 장식 없음.

### Don't
- 단계 색을 일반 버튼·본문·아이콘에 쓰지 않는다.
- 단계 카드 위에 `{colors.muted}` 를 쓰지 않는다.
- 그라데이션 카드 위에 흰 글자나 `{colors.brand}` 글자를 쓰지 않는다.
- 입력창을 알약으로 만들지 않는다.
- 본문을 18px 아래로 내리지 않는다 — MiniMax의 14px 본문은 이 사용자층에 옮기지 않는다.
- 단계 카드를 가로 스크롤·캐러셀로 만들지 않는다. 순서가 의미다.
- 어두운 푸터에 파란 링크를 쓰지 않는다.
- 히어로 자간을 -0.02em보다 조이지 않는다.

## Responsive Behavior

| Name | Width | Key Changes |
|---|---|---|
| Mobile | < 768px | 1단. 히어로 40px. 단계 카드는 라운드를 유지한 채 좌우 20px 여백(full-bleed로 바꾸지 않는다 — 카드가 "장"으로 읽혀야 한다). 버튼 쌍 세로 스택. |
| Desktop | ≥ 768px | 히어로 64px + 960px 2단(글 좌 / 목업 우). 섹션 80px. 단계 카드 안 2열 배치 가능(설명 좌 / 흰 카드 우). 본문 576px 유지. |

### Touch Targets
`tokens.yaml` 기준 그대로: 버튼·입력창 56px, 복사 버튼 48px, 인접 간격 12px, 링크 히트영역 44px.

알약 버튼은 세로 패딩으로 높이를 맞추지 않는다 — `height: 56px` 을 명시한다(패딩 계산에 의존하면 글꼴 로딩 전후로 높이가 흔들린다).

### Collapsing Strategy
- 히어로 2단 → 1단.
- 단계 카드 안 2열 → 1열. 카드 자체는 접히지 않는다.
- 스토어 버튼 쌍은 모든 폭에서 가로 2열.
- 프로모 띠는 < 480px에서 한 줄 말줄임.

## Iteration Guide

1. 값은 `tokens.yaml` 에서만 고친다. 이 문서에 헥스를 다시 쓰지 않는다.
2. 이 문서는 `overrides:` 와 `components:` 만 자기 것으로 갖는다. 오버라이드를 추가할 때는 **왜 기본값으로 부족한지**를 한 줄 적는다.
3. 새 단계가 생기면 먼저 색을 배정한다. 배정 없이 카드를 만들지 않는다.
4. 변형은 `components:` 의 개별 항목으로(`-pressed`, `-disabled`, `-on-vivid`).
5. 색을 바꾸면 `tokens.yaml` 의 `contrast-ledger` 를 다시 계산한다.
6. 강조가 고민되면: 크게보다 단계 카드로, 색보다 순서로.

## Known Gaps

- **`step-card-ink` 미배정.** 잉크 카드 사양은 있으나 쓸 섹션이 없다. 문의·긴급 연락이 생기면 그 자리.
- **프로모 띠 운용 주체 미정.** 기관별로 다른 문구가 필요한지, 누가 편집하는지 정해지지 않았다.
- **단계 수가 늘어날 때의 색 확장.** 현재 배정은 3+1색. 5단계 이상이 되면 색으로 단계를 구분하는 전략 자체를 재검토해야 한다(숫자 배지만 남기는 쪽).
- **모션 미정** — `tokens.yaml`의 `motion` 참조.
- **오류 케이스별 문구·다국어·다크 모드** — `tokens.yaml`의 `open-questions` 참조.
