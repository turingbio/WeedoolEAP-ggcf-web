---
version: alpha
name: WeeDool-EAP-web-v4
tokens: ./tokens.yaml
extends: ./tokens.yaml
description: 흰 캔버스와 잉크 활자로 조용히 흐르다가, 두세 화면마다 전면 시그니처 카드가 한 장씩 끼어드는 안내 시스템. **히어로에는 장식이 없다** — 하늘빛 그라데이션은 히어로 배경이 아니라 "계정 발급" 단계 하나를 감싸는 시그니처 표면으로 강등되고, 첫 화면은 흰 여백과 큰 활자와 버튼 한 쌍만으로 선다. 계정 발급 화면은 자기만의 방언을 쓴다 — 28px 값, tabular 숫자, 양수 자간.

overrides:
  typography:
    credential-lg: { size: 28px, weight: 700, line: 1.35, tracking: 0.56px, feature: tnum }
    credential-label: { size: 15px, weight: 600, line: 1.4 }
    credential-meta: { size: 17px, weight: 600, line: 1.5, feature: tnum }
  # 이유: 히어로에서 그라데이션을 뺀 대신, 계정 발급이 페이지의 시각적 정점이 되어야 한다.
  #       기본 credential(24px)로는 그 무게를 못 받는다.
  rounded:
    signature: 28px

components:
  top-nav:
    backgroundColor: "{colors.canvas}"
    logoHeight: 28px
    height: 64px
  hero-band:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.ink}"
    typography: "{typography.hero-mobile}"
    padding: "{spacing.section} {spacing.lg}"
  button-primary:
    backgroundColor: "{colors.brand}"
    textColor: "{colors.on-brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 24px"
  button-primary-active:
    backgroundColor: "{colors.brand-strong}"
  button-primary-disabled:
    backgroundColor: "{colors.disabled-bg}"
    textColor: "{colors.disabled-ink}"
  button-secondary:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    typography: "{typography.button}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
  button-secondary-on-signature:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.brand}"
    border: "1px solid {colors.brand}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
  button-secondary-disabled:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.disabled-ink}"
    border: "1px solid {colors.line-control}"
  button-pair:
    layout: "stack 12px (mobile) / row 12px (>=768px)"
    order: "primary first"
  button-icon-square:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    size: "{layout.icon-button}"
  signature-sky-card:
    backgroundColor: "{colors.block-sky}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.signature}"
    padding: "{spacing.huge} {spacing.lg}"
  signature-mint-card:
    backgroundColor: "{colors.block-mint}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.signature}"
    padding: "{spacing.huge} {spacing.lg}"
  signature-cream-card:
    backgroundColor: "{colors.block-cream}"
    textColor: "{colors.ink}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
  signature-issue-card:
    background: "{gradients.hero}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.signature}"
    padding: "{spacing.huge} {spacing.lg}"
  hero-card-dark:
    backgroundColor: "{colors.surface-dark}"
    textColor: "{colors.canvas}"
    rounded: "{overrides.rounded.signature}"
    padding: "{spacing.huge} {spacing.lg}"
  cta-band-light:
    backgroundColor: "{colors.brand-surface}"
    textColor: "{colors.ink}"
    rounded: "{overrides.rounded.signature}"
    padding: "{spacing.huge} {spacing.lg}"
  anonymity-card:
    backgroundColor: "{colors.canvas}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
    iconSize: 48px
  content-card:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
  mockup-frame:
    rounded: "{rounded.lg}"
    shadow: "{elevation.mockup}"
  text-input:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line-control}"
    rounded: "{rounded.sm}"
    height: "{layout.control-height}"
    padding: "0 16px"
    typography: "{typography.body}"
  text-input-focus:
    border: "2px solid {colors.brand}"
  text-input-error:
    border: "2px solid {colors.danger}"
    messageColor: "{colors.danger}"
    messageTypography: "{typography.caption}"
  credential-card:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
    valueTypography: "{overrides.typography.credential-lg}"
  credential-row:
    labelTypography: "{overrides.typography.credential-label}"
    labelColor: "{colors.muted}"
    valueTypography: "{overrides.typography.credential-lg}"
    divider: "1px solid {colors.line}"
  credential-expiry-row:
    backgroundColor: "{colors.block-cream}"
    textColor: "{colors.warning}"
    typography: "{overrides.typography.credential-meta}"
    padding: "14px {spacing.lg}"
  qr-plate:
    backgroundColor: "{colors.canvas}"
    border: "1px solid {colors.line}"
    rounded: "{rounded.sm}"
    padding: "{spacing.sm}"
    size: 160px
  footer:
    backgroundColor: "{colors.canvas}"
    textColor: "{colors.muted}"
    typography: "{typography.caption}"
    borderTop: "1px solid {colors.line}"
    padding: "{spacing.xxl} {spacing.lg}"
---

## Overview

기본 공기는 **흰 캔버스, 잉크 활자, 넉넉한 여백, 브랜드 블루 채움 버튼 하나**다. 아무것도 주의를 끌려 하지 않다가, 두세 화면마다 전면 시그니처 카드가 한 장 끼어든다 — 하늘·민트·크림, 그리고 거의 쓰지 않는 잉크. 그 사이의 페이지는 인쇄물처럼 읽힌다: 제목, 설명 두세 줄, 이미지 하나, 다시 여백.

**이 버전이 다른 버전들과 갈라지는 지점은 히어로에서 그라데이션을 뺀 것이다.** 하늘빛 그라데이션은 첫 화면의 분위기 장치가 아니라 **"계정 발급" 단계 하나를 감싸는 시그니처 표면**으로 내려온다. 첫 화면은 흰 여백과 큰 활자와 버튼 한 쌍만으로 선다. 브랜드의 힘을 배경이 아니라 활자와 여백이 증명하게 하고, 그라데이션은 페이지에서 가장 중요한 한 순간에만 등장시켜 값을 올리는 배치다.

**계정 발급 화면은 자기만의 방언을 쓴다.** 값은 28px + `tnum` + 양수 자간, 만료 줄은 크림 바탕. 이 페이지에 온 이유가 그 두 줄이므로, 다른 어떤 활자보다 크고 정확하게 만든다.

**Key Characteristics:**
- 주 CTA는 `{colors.brand}` 채움 + 12px 라운드 + 56px. 한 뷰포트에 하나.
- 보조 CTA는 흰 바탕 + 브랜드 테두리. 둘이 한 쌍으로 히어로와 마지막 밴드에 함께 선다.
- **히어로에 배경 장식이 없다.**
- 브랜드 전압은 시그니처 카드에 산다. 각 카드는 전면 표면이지 작은 요소의 강조색이 아니다.
- 섹션 리듬: 흰 캔버스 → 민트(익명성) → 흰 캔버스(앱 소개) → 그라데이션(계정 발급) → 흰 캔버스(앱 설치) → 하늘 CTA 밴드 → 푸터. **같은 표면 모드를 연속으로 두 번 쓰지 않는다.**
- 라운드가 위계다: 시그니처 28px, 카드 20px, 버튼·입력 12px, 태그 4px.
- 세로 리듬 상수 64px(데스크톱 80px). 모든 밴드가 같은 값.

## Colors

팔레트·대비표는 `tokens.yaml`. 이 버전의 배치:

### Signature Surfaces
전면 카드 표면으로만 등장하며, 작은 요소의 강조색으로 쓰지 않는다.

| 표면 | 토큰 | 쓰는 곳 |
|---|---|---|
| Mint | `{colors.block-mint}` | 익명성 서사 카드 |
| Issue Gradient | `{gradients.hero}` | **계정 발급 카드 — 페이지에서 유일한 그라데이션 배경** |
| Sky | `{colors.block-sky}` | 마지막 CTA 밴드, 일반 강조 카드 |
| Cream | `{colors.block-cream}` | 만료·주의 안내, 계정 카드의 만료 줄 |
| Lilac | `{colors.block-lilac}` | 예비. 현재 배정된 섹션 없음 |
| Ink | `{colors.surface-dark}` | 예비. 배정 없음(→ Known Gaps) |

### 이 버전이 경고하는 것
`{colors.heading-accent}`(#007DFB)는 **버튼 색이 아니다.** 흰 배경 3.94:1이라 24px 이상 Bold 제목 안 강조 구절에서만 쓴다. 이 값을 CTA에 쓰는 것이 이 시스템에서 가장 흔한 실수가 될 것이다 — 앱에서 강조색으로 쓰이는 값이라 손이 먼저 간다.

링크색과 버튼색은 둘 다 `{colors.brand}` 다. 브랜드 전압이 하나뿐이기 때문.

그라데이션 표면 위: 잉크만. muted(3.04)·brand(2.67)·흰 글자 금지.

## Typography

스케일은 `tokens.yaml`. 이 버전의 오버라이드는 credential 방언 세 토큰이다.

| Token | 값 | 쓰는 곳 |
|---|---|---|
| `credential-lg` | 28px / 700 / 0.56px / tnum | 발급 아이디·비밀번호 |
| `credential-label` | 15px / 600 | 계정 값 라벨 |
| `credential-meta` | 17px / 600 / tnum | 만료 시각 |

**이 세 토큰은 항상 함께 움직이며, 다른 섹션에서 꺼내 쓰지 않는다.** 다른 어디에도 양수 자간이 없으므로, 자간만으로도 "이 값은 받아적는 것" 이라는 신호가 된다.

원칙:
- 원본 시스템(Airtable)은 display를 굵게 쓰지 않지만, 이 시스템은 **700을 쓴다** — 한국어 고딕은 400에서 크기를 키우면 힘이 아니라 흐릿함이 된다. 대신 굵기를 400 / 600 / 700 셋으로 묶어 남용을 막는다.
- 본문 18px 하한. 15px은 캡션·오류 문구·푸터.
- 음수 자간은 24px 이상, -0.02em 이내. 양수 자간은 계정 값에만.

## Layout

`tokens.yaml`의 `layout` 기준.

- 본문 576px 중앙 정렬, 히어로만 960px(≥768px에서 글 좌 / 목업 우 2단).
- 시그니처 카드는 좌우 20px 여백 안에서 화면 폭을 채우고, 안쪽 콘텐츠는 다시 576px.
- 카드 내부 패딩: 시그니처 상하 48px · 좌우 20px, 일반 카드 20px.
- 섹션 세로 패딩 64px(데스크톱 80px) — **모든 밴드가 같은 값을 쓴다. 이 상수가 페이지의 유일한 리듬 장치다.**

### Whitespace Philosophy
여백이 이 버전의 주된 분위기 도구다. 히어로는 제목·설명·버튼 쌍 위아래로 64px 이상의 순수 여백을 두고, 그 안에 아무 장식도 넣지 않는다. **히어로는 의도적으로 조용하다** — 이 페이지를 여는 사람은 대개 회사에서 안내 링크를 받고 처음 들어온 사람이고, 첫 화면이 시끄러우면 광고로 읽힌다.

## Elevation & Depth

| Level | Treatment | Use |
|---|---|---|
| Flat | 그림자·테두리 없음 | 본문 섹션, 헤더, 푸터, 모든 버튼, 시그니처 카드 |
| Soft hairline | 1px `{colors.line}` | 계정 카드, 콘텐츠 카드, QR 판 |
| Control hairline | 1px `{colors.line-control}` | 입력창, 비활성 아웃라인 버튼 |
| Focus | `{elevation.focus}` | 모든 조작 요소 |
| Mockup | `{elevation.mockup}` | 앱 스크린 목업 — 유일한 실제 그림자 |

**색면이 먼저, 그림자는 나중.** 흰 캔버스와 시그니처 표면의 대비가 깊이를 만들고, 그림자는 "여기는 실제 제품 화면" 을 뜻하는 목업 한 곳에만 남는다.

## Shapes

`tokens.yaml`의 `rounded` + 이 버전의 `signature` 28px. 알약 버튼은 쓰지 않는다.

사진 기하: 배너 2.17:1 / 20px 라운드, 앱 목업 약 1:2 / 20px + Mockup 그림자, 캐릭터 PNG 투명 배경 그대로, QR 정사각 160px.

## Components

> 호버는 문서화하지 않는다. Default / Active / Disabled / Error만. 변형은 `components:` 의 개별 항목이다.

### Buttons
- **`button-primary`** — 뷰포트당 하나. 로딩은 스피너 없이 라벨 교체 + `aria-busy="true"`. 비활성은 사유 캡션 필수(2.50:1).
- **`button-secondary`** — 흰 바탕 + 브랜드 테두리. primary와 한 쌍으로 서는 것이 이 시스템의 시그니처 버튼 행이다.
- **`button-secondary-on-signature`** — 시그니처 카드 위에서도 **흰 바탕을 유지**한다. 반투명 온다크 스타일로 바꾸지 않는다 — 흰 면이 밝은 표면 위에서도 가장 또렷한 도형이다. 잉크 카드 위에서만 테두리·글자를 흰색으로 반전.
- **`button-pair`** — 모바일 세로 스택 / ≥768px 가로 2열, 언제나 primary 먼저. 단 스토어 버튼 쌍은 모든 폭에서 가로 2열.
- **`button-icon-square`** — 48px 복사 버튼. 성공 시 "복사했어요" 를 문구로.

### Bands & Signature Cards
- **`hero-band`** — 흰 캔버스. 표면 카드도 테두리도 그림자도 그라데이션도 없다. h1 + 설명 + 버튼 쌍이 64px 여백 안에 선다.
- **`signature-mint-card`** — 익명성. 안에 흰 `anonymity-card` 3장을 12px 간격으로.
- **`signature-issue-card`** — **계정 발급.** 페이지에서 유일한 그라데이션 표면. 안에 기관코드 입력과 계정 카드가 들어간다. 위 글자는 잉크만. 이 카드 안의 CTA는 예외적으로 `button-primary`(채움)를 쓴다 — 밝은 표면이라 파랑이 살아 있다.
- **`signature-sky-card`** / **`cta-band-light`** — 하늘 표면. 강조 카드와 푸터 위 마지막 CTA 밴드.
- **`signature-cream-card`** — 주의·만료 안내.
- **`hero-card-dark`** — 잉크 카드. 사양만 정의, 배정 없음.

### Credential Sub-System
- **`credential-card`** — `signature-issue-card` 안에 놓인다. 페이지에서 가장 중요한 흰 면이 가장 또렷한 표면 위에 앉는다.
- **`credential-row`** — 라벨 위 / 값 아래(`credential-lg` + tnum), 오른쪽에 복사 버튼, 아이디·비밀번호 사이 구분선.
- **`credential-expiry-row`** — 크림 줄, `credential-meta`. 절대시각 표기(`2026년 9월 14일 18:00까지 유효`).
- **PNG 저장** — `tokens.yaml`의 `account-png-export`. 단 이 버전은 저장 이미지 안의 값도 28px(`credential-lg`)로 맞춘다.

### Forms
- **`text-input`** — 라벨은 위 8px. placeholder를 라벨로 쓰지 않는다. 오류는 테두리 + 아래 문구 한 쌍. 시그니처 표면 위에서도 배경은 흰색.

### Navigation & Footer
- **`top-nav`** — 흰 바 64px, 로고만. 히어로가 흰 캔버스이므로 헤더도 투명이 아니라 흰색이다(다른 버전과의 차이).
- **`footer`** — 흰 캔버스(시그니처 표면 아님), 위 1px 구분선, 좌측 정렬.

## Do's and Don'ts

### Do
- 채움 버튼을 뷰포트당 하나로 유지한다.
- primary + secondary 를 한 쌍으로 쓴다.
- **히어로의 여백을 신뢰한다.** 그라데이션·메시·배경 일러스트를 넣지 않는다.
- 그라데이션은 계정 발급 카드 한 곳에만 — 희소해야 값이 있다.
- 시그니처 표면 위 카드는 흰색으로.
- 같은 표면 모드를 연속 두 밴드에 쓰지 않는다.
- 모든 밴드에 64px(데스크톱 80px) 세로 패딩.

### Don't
- `{colors.heading-accent}` 를 버튼·본문·링크에 쓰지 않는다.
- **히어로에 그라데이션을 되돌려 넣지 않는다** — 이 버전의 전제가 무너진다.
- 그라데이션 표면 위에 muted·brand·흰 글자를 얹지 않는다.
- `{colors.line}` 을 입력창 테두리로 쓰지 않는다.
- display를 400으로 내리지 않는다 — 한국어 고딕은 큰 크기에서 400이면 흐릿해진다.
- 알약 버튼을 쓰지 않는다.
- credential 방언 토큰을 다른 섹션에서 꺼내 쓰지 않는다.
- 호버 스타일을 임의로 추가하지 않는다.

## Responsive Behavior

| Name | Width | Key Changes |
|---|---|---|
| Mobile | < 768px | 1단, 좌우 20px, 섹션 64px, h1 32px / 시그니처 제목 28px. 버튼 쌍 세로 스택. **시그니처 카드는 라운드를 버리고 full-bleed.** |
| Desktop | ≥ 768px | 히어로 960px 2단, 섹션 80px, h1 44px. 버튼 쌍 가로 2열. 시그니처 카드는 좌우 20px 여백 + 28px 라운드. 본문 576px 유지. |

### Touch Targets
버튼·입력창 56px, 복사 버튼 48px, 인접 간격 12px, 링크 히트영역 44px.

### Collapsing
- 히어로 2단 → 1단.
- 버튼 쌍: 가로 2열 → 세로 스택(스토어 쌍 제외).
- 시그니처 카드: 라운드 카드 → full-bleed 밴드.
- 본문 폭은 브레이크포인트를 타지 않는다.

## Iteration Guide

1. 값은 `tokens.yaml` 에서만.
2. 새 컴포넌트를 추가하기 전에 어느 하위 시스템인지 정한다 — 본 시스템인가, credential 방언인가.
3. 변형은 `components:` 의 개별 항목으로. 프로즈에 묻지 않는다.
4. 호버는 문서화하지 않는다.
5. 강조가 고민되면: 굵게보다 크게, 강조색보다 시그니처 표면.

## Known Gaps

- **`hero-card-dark`(잉크 카드)에 배정된 섹션이 없다.** "안심" 정서와 충돌할 수 있어 보류했다. 쓴다면 페이지당 한 번, 아마도 마지막 CTA.
- **`block-lilac` 미사용.** 앱 기능 소개가 늘어나면 그 자리.
- **호버·모션 미문서화.** `{motion.button}` 외 정의 없음.
- 그 외는 `tokens.yaml` 의 `open-questions`.
